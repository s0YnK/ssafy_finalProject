<script setup>
import HomePage from '@/views/HomePage.vue';
</script>

<template>
  <HomePage />
</template>

<style scoped></style>
