<template>
    <div>
        커뮤니티
    </div>
</template>

<script setup>

</script>

<style scoped></style>